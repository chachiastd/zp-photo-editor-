package com.razeditor.app.frame;

import ja.burhanrashid52.photoeditor.PhotoFilter;

public interface FrameListener {
    void onFrameSelected(PhotoFilter photoFilter);
}